#ifndef SHA_H_
#define SHA_H_




void SHA256(uint8_t *, uint8_t, uint8_t *); 


#endif
