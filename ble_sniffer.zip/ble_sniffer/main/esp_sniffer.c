/*
   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/


/****************************************************************************
*
* This file is used for eddystone receiver.
*
****************************************************************************/

#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include <rom/uart.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <sys/unistd.h>
#include <sys/stat.h>


#include "esp_bt.h"
#include "nvs_flash.h"
#include "esp_log.h"
#include "esp_bt_defs.h"
#include "esp_bt_main.h"
#include "esp_gatt_defs.h"
#include "esp_gattc_api.h"
#include "esp_gap_ble_api.h"
#include "freertos/FreeRTOS.h"

#include "freertos/task.h"
#include "freertos/event_groups.h"

#include "esp_eddystone_protocol.h"
#include "esp_eddystone_api.h"

#include "esp_vfs_fat.h"
#include "driver/sdmmc_host.h"
#include "driver/sdspi_host.h"
#include "sdmmc_cmd.h"
#include "ds1302.h"
#include "sha.h"

#include "driver/uart.h"



#define USE_SPI_MODE

#ifdef USE_SPI_MODE
// Pin mapping when using SPI mode.
// With this mapping, SD card can be used both in SPI and 1-line SD mode.
// Note that a pull-up on CS line is required in SD mode.
#define PIN_NUM_MISO 19
#define PIN_NUM_MOSI 23
#define PIN_NUM_CLK  18
#define PIN_NUM_CS   5
#endif //USE_SPI_MODE



// You have to set these CONFIG value using menuconfig.
#if 1
#define CONFIG_CLK_GPIO		12
#define CONFIG_IO_GPIO		14
#define CONFIG_CE_GPIO		27
#define	CONFIG_TIMEZONE		9
#endif


typedef struct {
    DS1302_DateTime time;     //!< Second 0..59
    int16_t rssi;     //!< Minute 0..59
    uint8_t mac[6];
} ScanHit;

#define SCAN_BUFFER_SIZE 2000

ScanHit hit_table[SCAN_BUFFER_SIZE];
uint16_t buffer_count, buffer_full;
uint8_t rtc_started = 0;
uint8_t m_sd_error=0;

DS1302_DateTime latest_rtc_val;


static const char* DEMO_TAG = "BLE_SNIFFER V1";

/* declare static functions */
static void esp_gap_cb(esp_gap_ble_cb_event_t event, esp_ble_gap_cb_param_t* param);
static void esp_eddystone_show_inform(const esp_eddystone_result_t* res);

static esp_ble_scan_params_t ble_scan_params = {
    .scan_type              = BLE_SCAN_TYPE_ACTIVE,
    .own_addr_type          = BLE_ADDR_TYPE_PUBLIC,
    .scan_filter_policy     = BLE_SCAN_FILTER_ALLOW_ALL,
    .scan_interval          = 0x50,
    .scan_window            = 0x30,
    .scan_duplicate         = BLE_SCAN_DUPLICATE_DISABLE
};


void getClock(void *);
void InitSD(void);
void WriteDatatoSD(void);
void TestSHA(void);
uint8_t CheckForTimeUpdate(void);

static void esp_eddystone_show_inform(const esp_eddystone_result_t* res)
{
    switch(res->common.frame_type)
    {
        case EDDYSTONE_FRAME_TYPE_UID: {
            ESP_LOGI(DEMO_TAG, "Eddystone UID inform:");
            ESP_LOGI(DEMO_TAG, "Measured power(RSSI at 0m distance):%d dbm", res->inform.uid.ranging_data);
            ESP_LOGI(DEMO_TAG, "EDDYSTONE_DEMO: Namespace ID:0x");
            esp_log_buffer_hex(DEMO_TAG, res->inform.uid.namespace_id, 10);
            ESP_LOGI(DEMO_TAG, "EDDYSTONE_DEMO: Instance ID:0x");
            esp_log_buffer_hex(DEMO_TAG, res->inform.uid.instance_id, 6);
            break;
        }
        case EDDYSTONE_FRAME_TYPE_URL: {
            ESP_LOGI(DEMO_TAG, "Eddystone URL inform:");
            ESP_LOGI(DEMO_TAG, "Measured power(RSSI at 0m distance):%d dbm", res->inform.url.tx_power);
            ESP_LOGI(DEMO_TAG, "URL: %s", res->inform.url.url);
            break;
        }
        case EDDYSTONE_FRAME_TYPE_TLM: {
            ESP_LOGI(DEMO_TAG, "Eddystone TLM inform:");
            ESP_LOGI(DEMO_TAG, "version: %d", res->inform.tlm.version);
            ESP_LOGI(DEMO_TAG, "battery voltage: %d mV", res->inform.tlm.battery_voltage);
            ESP_LOGI(DEMO_TAG, "beacon temperature in degrees Celsius: %6.1f", res->inform.tlm.temperature);
            ESP_LOGI(DEMO_TAG, "adv pdu count since power-up: %d", res->inform.tlm.adv_count);
            ESP_LOGI(DEMO_TAG, "time since power-up: %d s", res->inform.tlm.time);
            break;
        }
        default:
            break;
    }
}

static void esp_gap_cb(esp_gap_ble_cb_event_t event, esp_ble_gap_cb_param_t* param)
{
    esp_err_t err;

    switch(event)
    {
        case ESP_GAP_BLE_SCAN_PARAM_SET_COMPLETE_EVT: {
            uint32_t duration = 0;
            esp_ble_gap_start_scanning(duration);
            break;
        }
        case ESP_GAP_BLE_SCAN_START_COMPLETE_EVT: {
            if((err = param->scan_start_cmpl.status) != ESP_BT_STATUS_SUCCESS) {
                ESP_LOGE(DEMO_TAG,"Scan start failed: %s", esp_err_to_name(err));
            }
            else {
                ESP_LOGI(DEMO_TAG,"Start scanning...");
            }
            break;
        }
        case ESP_GAP_BLE_SCAN_RESULT_EVT: {
            esp_ble_gap_cb_param_t* scan_result = (esp_ble_gap_cb_param_t*)param;
            switch(scan_result->scan_rst.search_evt)
            {
                case ESP_GAP_SEARCH_INQ_RES_EVT: {
					
					
#if 1
					 uint8_t *addr = scan_result->scan_rst.bda;
			
						uint8_t adv[64];
									
						//copy over the first few 8 bytes
						for(uint8_t i=0;i<32;i++){
							adv[i]=scan_result->scan_rst.ble_adv[i];
						}
						adv[32]=0;
						
						//esp_log_buffer_hex("Address:", scan_result->scan_rst.bda, ESP_BD_ADDR_LEN);
						//int rsii = scan_result->scan_rst.rssi;   

						if(rtc_started!=0){
							if(buffer_count!=SCAN_BUFFER_SIZE){
								hit_table[buffer_count].time = latest_rtc_val;
								hit_table[buffer_count].rssi = scan_result->scan_rst.rssi;
								memcpy(hit_table[buffer_count].mac, scan_result->scan_rst.bda, ESP_BD_ADDR_LEN);
								buffer_count++;
								//ESP_LOGI(DEMO_TAG, "stored");
								buffer_full = 0;
								}
							else{
								if(buffer_full==0){
									buffer_full = 1;
									ESP_LOGI(DEMO_TAG, "buffer full");
								}
								
							}
						}
           // printf("Device %s, RSSI=%i\n", mac, rssi);
		
		

#else					
					
					
                    esp_eddystone_result_t eddystone_res;
                    memset(&eddystone_res, 0, sizeof(eddystone_res));
                    esp_err_t ret = esp_eddystone_decode(scan_result->scan_rst.ble_adv, scan_result->scan_rst.adv_data_len, &eddystone_res);
                    if (ret) {
                        // error:The received data is not an eddystone frame packet or a correct eddystone frame packet.
                        // just return
						ESP_LOGI(DEMO_TAG, "non eddy stone");
						
						
						
						
                        return;
                    } else {   
                        // The received adv data is a correct eddystone frame packet.
                        // Here, we get the eddystone infomation in eddystone_res, we can use the data in res to do other things.
                        // For example, just print them:
                        ESP_LOGI(DEMO_TAG, "--------Eddystone Found----------");
                        esp_log_buffer_hex("EDDYSTONE_DEMO: Device address:", scan_result->scan_rst.bda, ESP_BD_ADDR_LEN);
                        ESP_LOGI(DEMO_TAG, "RSSI of packet:%d dbm", scan_result->scan_rst.rssi);
                        esp_eddystone_show_inform(&eddystone_res);
                    }
#endif					
                    break;
                }
                default:
                    break;
            }
            break;
        }
        case ESP_GAP_BLE_SCAN_STOP_COMPLETE_EVT:{
            if((err = param->scan_stop_cmpl.status) != ESP_BT_STATUS_SUCCESS) {
                ESP_LOGE(DEMO_TAG,"Scan stop failed: %s", esp_err_to_name(err));
            }
            else {
                ESP_LOGI(DEMO_TAG,"Stop scan successfully");
            }
            break;
        }
        default:
            break;
    }
}

void esp_eddystone_appRegister(void)
{
    esp_err_t status;
    
    ESP_LOGI(DEMO_TAG,"Register callback");

    /*<! register the scan callback function to the gap module */
    if((status = esp_ble_gap_register_callback(esp_gap_cb)) != ESP_OK) {
        ESP_LOGE(DEMO_TAG,"gap register error: %s", esp_err_to_name(status));
        return;
    }
}

void esp_eddystone_init(void)
{
    esp_bluedroid_init();
    esp_bluedroid_enable();
    esp_eddystone_appRegister();

	}

	
char time_entry_str[6][10]={"HOUR\0","MIN\0","SECONDS\0","DAY\0","MONTH\0","YEAR\0"};
	
#define ECHO_TEST_TXD  (GPIO_NUM_1)
#define ECHO_TEST_RXD  (GPIO_NUM_3)
#define ECHO_TEST_RTS  (UART_PIN_NO_CHANGE)
#define ECHO_TEST_CTS  (UART_PIN_NO_CHANGE)

#define LED_GPIO 13 //GPIO_SEL_13


#define BUF_SIZE 1024

void app_main()
{
	size_t buffered_size;

	static uint8_t data[BUF_SIZE],  base_mac[6];
	static char txdata[100],rxdata[100];
	static int rtc_data[6];
	static int txlen=0,entry=0,rxlen=0,x=0,state=0;
	
	gpio_pad_select_gpio(LED_GPIO);
    gpio_set_direction(LED_GPIO, GPIO_MODE_OUTPUT);
  
	esp_read_mac(base_mac, 0);
	
	
	ESP_LOGI(DEMO_TAG, "Unit MAC, %02x:%02x:%02x:%02x:%02x:%02x,\r\n",base_mac[0], base_mac[1],base_mac[2],base_mac[3],base_mac[4],base_mac[5] );
	
	
	
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_bt_controller_mem_release(ESP_BT_MODE_CLASSIC_BT));
    esp_bt_controller_config_t bt_cfg = BT_CONTROLLER_INIT_CONFIG_DEFAULT();
    esp_bt_controller_init(&bt_cfg);
    esp_bt_controller_enable(ESP_BT_MODE_BLE);
 
 

#if 0
	
	char var[100];
	for(int i =0;i<10;i++){
	
		ESP_LOGI(DEMO_TAG, "*");

		//fscanf("%s\n", var);
		
		if(CheckForTimeUpdate()==1)break;
		
		vTaskDelay(100);
	}
	
	
#endif
	//uart_driver_delete(UART_NUM_1);
	esp_log_level_set(DEMO_TAG, ESP_LOG_VERBOSE);
	
	TestSHA();

	
	InitSD();
	//WriteDatatoSD();
	//WriteDatatoSD();
 
	buffer_count = 0;
	
    esp_eddystone_init();

    /*<! set scan parameters */
    esp_ble_gap_set_scan_params(&ble_scan_params);
	
	xTaskCreate(getClock, "getClock", 1024*4, NULL, 2, NULL);
	 
}


uint8_t CheckForTimeUpdate(void){
	
	static char rxdata[100];
	static int rxlen=0,x=0;
	
		uint8_t myChar;
		STATUS s = uart_rx_one_char(&myChar);
		 if (s == OK){ 
		
			if(myChar=='T'){
				rxlen=0;
				while(rxlen < 19){
					STATUS s = uart_rx_one_char(&myChar);
					if (s == OK){ 
						rxdata[rxlen]=myChar;
						rxlen++;
						}
					vTaskDelay(1);
				}
				
				rxdata[rxlen]=0;
				ESP_LOGI(DEMO_TAG, "%s",rxdata );
				
				DS1302_DateTime dt;
					
				if(rxdata[10]=='T'){
						//Chop up string!!
						rxdata[4]=0;
						rxdata[7]=0;
						rxdata[10]=0;
						rxdata[13]=0;
						rxdata[16]=0;
						rxdata[19]=0;


						dt.second = atoi(&rxdata[17]);;
						dt.minute =  atoi(&rxdata[14]);;
						dt.hour = atoi(&rxdata[11]);
						dt.dayWeek = 1; // 0= Sunday 1 = Monday
						dt.dayMonth = atoi(&rxdata[8]);
						dt.month = atoi(&rxdata[5]);
						dt.year = atoi(&rxdata[0]);
						
						
						DS1302_Dev dev;
						if (!DS1302_begin(&dev, CONFIG_CLK_GPIO, CONFIG_IO_GPIO, CONFIG_CE_GPIO)) {
								ESP_LOGE(pcTaskGetTaskName(0), "Error: DS1302 begin");
							}
							else{
								ESP_LOGI(pcTaskGetTaskName(0), "Set initial date time...");
						
						
								DS1302_setDateTime(&dev, &dt);
								
								

								
							}
							
				
					}
					
				return 1;
				
			
			}
			
			
		 }
		 return 0;
		 
}

void TestSHA(void){
	
	
	
	char out_sha_str[200];
	char mac_array[50];
	
	strcpy(mac_array,"applecake11:22:33:44:55:66");
	SHA256((uint8_t *)mac_array, strlen(mac_array), (uint8_t *)out_sha_str);
		
	ESP_LOGI(DEMO_TAG, "SHA: %s", out_sha_str);
		
}



void getClock(void *pvParameters)
{
    DS1302_Dev dev;
    DS1302_DateTime dt;
	
    // Check RTC has been Initialized
    if (!DS1302_begin(&dev, CONFIG_CLK_GPIO, CONFIG_IO_GPIO, CONFIG_CE_GPIO)) {
        ESP_LOGE(DEMO_TAG, "Error: DS1302 begin");
		m_sd_error =1;
		gpio_set_level(LED_GPIO,1);
        while (1) { vTaskDelay(1); }
    }
	else{
		
#if 0
		    // Set initial date and time
			dt.second = 0;
			dt.minute = 5;
			dt.hour = 16;
			dt.dayWeek = 1; // 0= Sunday 1 = Monday
			dt.dayMonth = 27;
			dt.month = 7;
			dt.year = 2020;
			DS1302_setDateTime(&dev, &dt);

#endif		
	}

    // Initialise the xLastWakeTime variable with the current time.
    TickType_t xLastWakeTime = xTaskGetTickCount();
    while(1) {
        // Get RTC date and time
        if (!DS1302_getDateTime(&dev, &dt)) {
            ESP_LOGE(DEMO_TAG, "Error: DS1302 read failed");
        } else {
            ESP_LOGI(DEMO_TAG, "T=%04d-%02d-%02dT%02d:%02d:%02d SD=%d",
                 dt.year, dt.month, dt.dayMonth,  dt.hour, dt.minute, dt.second, m_sd_error);
			latest_rtc_val = dt;
			rtc_started = 1;
        }
        vTaskDelayUntil(&xLastWakeTime, 100);
		
		if(dt.second==5 && m_sd_error == 0){
			gpio_set_level(LED_GPIO,0);
			}
		//ever 60 seconds we need to flush the buffer out to the SD Card... 
		if(dt.second==0){
			 
			 //disable scanning
			esp_ble_gap_stop_scanning();
			 //write SD Card
 			// ESP_LOGI(DEMO_TAG, "Pushing to SD Card");

			 //empty buffer
		 	
			//ESP_LOGI(DEMO_TAG, "Buffer Clear");
			//for(uint16_t i = 0;i<buffer_count;i++){
			//	ESP_LOGI(DEMO_TAG, "data %d, %d", i,hit_table[i].rssi );
			//}
			ESP_LOGI(DEMO_TAG, "%d %02d-%02d-%d %d:%02d:%02d",
                 dt.dayWeek, dt.dayMonth, dt.month, dt.year, dt.hour, dt.minute, dt.second);
			WriteDatatoSD();
			buffer_count = 0;
			
			 //enable scanning
			esp_ble_gap_start_scanning(120);
			 
		}
		
		CheckForTimeUpdate();
		
    }
}

static  sdspi_slot_config_t slot_config= SDSPI_SLOT_CONFIG_DEFAULT();
     // Options for mounting the filesystem.
    // If format_if_mount_failed is set to true, SD card will be partitioned and
    // formatted in case when mounting fails.
 static esp_vfs_fat_sdmmc_mount_config_t mount_config = {
        .format_if_mount_failed = false,
        .max_files = 5,
        .allocation_unit_size = 16 * 1024
    };
static sdmmc_host_t host= SDSPI_HOST_DEFAULT();
	
void InitSD(void){


    ESP_LOGI(DEMO_TAG, "Using SPI peripheral");

    m_sd_error = 0;

  
    slot_config.gpio_miso = PIN_NUM_MISO;
    slot_config.gpio_mosi = PIN_NUM_MOSI;
    slot_config.gpio_sck  = PIN_NUM_CLK;
    slot_config.gpio_cs   = PIN_NUM_CS;
    // This initializes the slot without card detect (CD) and write protect (WP) signals.
    // Modify slot_config.gpio_cd and slot_config.gpio_wp if your board has these signals.



    // Use settings defined above to initialize SD card and mount FAT filesystem.
    // Note: esp_vfs_fat_sdmmc_mount is an all-in-one convenience function.
    // Please check its source code and implement error recovery when developing
    // production applications.
    sdmmc_card_t* card;
    esp_err_t ret = esp_vfs_fat_sdmmc_mount("/sdcard", &host, &slot_config, &mount_config, &card);

    if (ret != ESP_OK) {
		m_sd_error = 1;
		gpio_set_level(LED_GPIO,1);
		
        if (ret == ESP_FAIL) {
            ESP_LOGE(DEMO_TAG, "Failed to mount filesystem. "
                "If you want the card to be formatted, set format_if_mount_failed = true.");
        } else {
            ESP_LOGE(DEMO_TAG, "Failed to initialize the card (%s). "
                "Make sure SD card lines have pull-up resistors in place.", esp_err_to_name(ret));
        }
        return;
    }

    // Card has been initialized, print its properties
    sdmmc_card_print_info(stdout, card);

    // Use POSIX and C standard library functions to work with files.
    // First create a file.
    ESP_LOGI(DEMO_TAG, "Opening file");
    FILE* f = fopen("/sdcard/hello.txt", "w");
    if (f == NULL) {
        ESP_LOGE(DEMO_TAG, "Failed to open file for writing");
        return;
    }
    fprintf(f, "Hello %s!\n", card->cid.name);
    fclose(f);
    ESP_LOGI(DEMO_TAG, "File written");

    // Check if destination file exists before renaming
    struct stat st;
    if (stat("/sdcard/foo.txt", &st) == 0) {
        // Delete it if it exists
        unlink("/sdcard/foo.txt");
    }

    // Rename original file
    ESP_LOGI(DEMO_TAG, "Renaming file");
    if (rename("/sdcard/hello.txt", "/sdcard/foo.txt") != 0) {
        ESP_LOGE(DEMO_TAG, "Rename failed");
        return;
    }

    // Open renamed file for reading
    ESP_LOGI(DEMO_TAG, "Reading file");
    f = fopen("/sdcard/foo.txt", "r");
    if (f == NULL) {
        ESP_LOGE(DEMO_TAG, "Failed to open file for reading");
        return;
    }
    char line[64];
    fgets(line, sizeof(line), f);
    fclose(f);
    // strip newline
    char* pos = strchr(line, '\n');
    if (pos) {
        *pos = '\0';
    }
    ESP_LOGI(DEMO_TAG, "Read from file: '%s'", line);

    // All done, unmount partition and disable SDMMC or SPI peripheral
  //  esp_vfs_fat_sdmmc_unmount();
   // ESP_LOGI(DEMO_TAG, "Card unmounted");
	
}



void WriteDatatoSD(void){
	char out_sha_str[256]; // should only 64 bytes of this! 
	uint8_t write_header;

  #if 0

    // Use settings defined above to initialize SD card and mount FAT filesystem.
    // Note: esp_vfs_fat_sdmmc_mount is an all-in-one convenience function.
    // Please check its source code and implement error recovery when developing
    // production applications.
    sdmmc_card_t* card;
    esp_err_t ret = esp_vfs_fat_sdmmc_mount("/sdcard", &host, &slot_config, &mount_config, &card);

    if (ret != ESP_OK) {
        if (ret == ESP_FAIL) {
            ESP_LOGE(DEMO_TAG, "Failed to mount filesystem. "
                "If you want the card to be formatted, set format_if_mount_failed = true.");
        } else {
            ESP_LOGE(DEMO_TAG, "Failed to initialize the card (%s). "
                "Make sure SD card lines have pull-up resistors in place.", esp_err_to_name(ret));
        }
        return;
    }

    // Card has been initialized, print its properties
    //sdmmc_card_print_info(stdout, card);
	
#endif
    // Use POSIX and C standard library functions to work with files.
    // First create a file.
    ESP_LOGI(DEMO_TAG, "Opening file");
	
	char fname[100];
	sprintf(fname, "/sdcard/mac%02d_%02d.csv",latest_rtc_val.dayMonth,latest_rtc_val.month);
//	sprintf(fname, "/sdcard/mac_log.csv");
	
#if 1	
	char fmode[10];
	struct stat st;
	
	//ESP_LOGI(DEMO_TAG, "f_stat(f) %d ", stat(fname, &st));
	
	  if(stat(fname, &st)!=0){
			write_header = 1;
		}
		else{
			write_header =0;
		}
#endif
	
#if 0	
	FRESULT fr;
    FILINFO fno;
	
	fno.lfsize = 100;
	
	
	fr = f_stat(fname, &fno);
	
	ESP_LOGI(DEMO_TAG, "f_stat(f) %d ", fr);
	
	if(fr!=FR_OK){
		write_header = 1;
	}
	else{
		write_header =0;
	}
#endif	
	
	
	
   FIL* f = fopen(fname, "a");
	
	
	//FILE* f = fopen("/sdcard/mac_log.csv", "w");

    if (f == NULL) {
		m_sd_error = 1;
		gpio_set_level(LED_GPIO,1);
        ESP_LOGE(DEMO_TAG, "Failed to open file for writing %s", fname);
        return;
    }
	
#if 1	
	/* LED ON */
	//gpio_set_level(LED_GPIO,1);
	// ESP_LOGI(DEMO_TAG, "f_tell(f) %lu ", f_size(f));
	 
	if(write_header==1){
		uint8_t base_mac[6];
		//esp_base_mac_addr_get(base_mac);
		esp_read_mac(base_mac, 0);

			//write out the header to the file. 
		fprintf(f, "Unit MAC, %02x:%02x:%02x:%02x:%02x:%02x,\r\n",base_mac[0], base_mac[1],base_mac[2],base_mac[3],base_mac[4],base_mac[5] );
	}
#endif	
	
	char mac_array[50];
	for(uint16_t i = 0; i<buffer_count  ; i++){
		
		
		sprintf(mac_array, "applecake%02x:%02x:%02x:%02x:%02x:%02x", hit_table[i].mac[0], hit_table[i].mac[1], hit_table[i].mac[2], hit_table[i].mac[3], hit_table[i].mac[4], hit_table[i].mac[5]);

		
		SHA256((uint8_t *)mac_array, strlen(mac_array), (uint8_t *)out_sha_str);
		
		fprintf(f, "%d-%02d-%02d %02d:%02d:%02d, %s, %d\r\n",hit_table[i].time.year,hit_table[i].time.month,hit_table[i].time.dayMonth, hit_table[i].time.hour, hit_table[i].time.minute, hit_table[i].time.second,  out_sha_str, hit_table[i].rssi );
  
		//fprintf(f, " \r\n", card->cid.name);
	}
	
    fclose(f);
    ESP_LOGI(DEMO_TAG, "File written %s ", fname);
	gpio_set_level(LED_GPIO,1);
    
	/* LED OFF */
	//gpio_set_level(LED_GPIO,0);


    // All done, unmount partition and disable SDMMC or SPI peripheral
    //esp_vfs_fat_sdmmc_unmount();
    //ESP_LOGI(DEMO_TAG, "Card unmounted");
	
}